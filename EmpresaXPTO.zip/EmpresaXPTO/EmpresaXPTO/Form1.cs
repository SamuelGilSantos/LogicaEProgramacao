﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmpresaXPTO
{
    public partial class FrmCadCliente : Form
    {
        public FrmCadCliente()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            string nomeCliente = txtNome.Text;
            int idade = int.Parse(txtIdade.Text);
            float altura = float.Parse(txtAltura.Text);
            MessageBox.Show("Nome do cliente: " + nomeCliente);
            MessageBox.Show("Idade do cliente: " + idade);
            MessageBox.Show("Altura do cliente: " + altura);
        }
    }
}
