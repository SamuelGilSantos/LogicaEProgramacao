﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Samuel_Gil
{
    public partial class FrmExercício03 : Form
    {
        public FrmExercício03()
        {
            InitializeComponent();
        }

        private void txtVlrPago_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            float VlrQuilo = 34;
            float VlrPeso = float.Parse(txtVlrPago.Text);
            float resultado;

            resultado = VlrPeso * VlrQuilo;

            lblTotal.Text = "Seu prato deu " + resultado + " reais";
        }
    }
}
