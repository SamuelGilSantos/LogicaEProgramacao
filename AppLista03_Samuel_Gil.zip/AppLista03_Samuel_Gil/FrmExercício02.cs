﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03_Samuel_Gil
{
    public partial class FrmExercício02 : Form
    {
        public FrmExercício02()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            float vlrPagar = float.Parse(txtPago.Text);
            float vlrLitro = float.Parse(txtGas.Text);
            float resultado;


            resultado = vlrPagar / vlrLitro;

            lblResultado.Text = "Você abasteceu " + resultado + " litros";
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
