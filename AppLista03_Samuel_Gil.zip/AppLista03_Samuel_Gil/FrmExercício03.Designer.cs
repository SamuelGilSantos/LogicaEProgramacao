﻿namespace AppLista03_Samuel_Gil
{
    partial class FrmExercício03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblVlrPago = new System.Windows.Forms.Label();
            this.txtVlrPago = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnCalc = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Tomato;
            this.panel2.Location = new System.Drawing.Point(-3, 2);
            this.panel2.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(666, 73);
            this.panel2.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Coral;
            this.panel1.Controls.Add(this.btnCalc);
            this.panel1.Controls.Add(this.lblTotal);
            this.panel1.Controls.Add(this.txtVlrPago);
            this.panel1.Controls.Add(this.lblVlrPago);
            this.panel1.Location = new System.Drawing.Point(-3, 75);
            this.panel1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(666, 309);
            this.panel1.TabIndex = 2;
            // 
            // lblVlrPago
            // 
            this.lblVlrPago.AutoSize = true;
            this.lblVlrPago.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVlrPago.Location = new System.Drawing.Point(220, 72);
            this.lblVlrPago.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblVlrPago.Name = "lblVlrPago";
            this.lblVlrPago.Size = new System.Drawing.Size(228, 22);
            this.lblVlrPago.TabIndex = 1;
            this.lblVlrPago.Text = "Peso do Prato (em quilos):";
            // 
            // txtVlrPago
            // 
            this.txtVlrPago.Location = new System.Drawing.Point(224, 114);
            this.txtVlrPago.Name = "txtVlrPago";
            this.txtVlrPago.Size = new System.Drawing.Size(204, 28);
            this.txtVlrPago.TabIndex = 3;
            this.txtVlrPago.TextChanged += new System.EventHandler(this.txtVlrPago_TextChanged);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(220, 255);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(0, 22);
            this.lblTotal.TabIndex = 4;
            // 
            // btnCalc
            // 
            this.btnCalc.BackColor = System.Drawing.Color.Coral;
            this.btnCalc.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnCalc.Location = new System.Drawing.Point(269, 178);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(103, 47);
            this.btnCalc.TabIndex = 5;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = false;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // FrmExercício03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 381);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "FrmExercício03";
            this.Text = "FrmExercício03";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblVlrPago;
        private System.Windows.Forms.TextBox txtVlrPago;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lblTotal;
    }
}