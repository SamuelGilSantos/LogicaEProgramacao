﻿namespace AppLista03_Samuel_Gil
{
    partial class FrmExercício02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtPago = new System.Windows.Forms.TextBox();
            this.lblPago = new System.Windows.Forms.Label();
            this.lblGas = new System.Windows.Forms.Label();
            this.txtGas = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCalc = new System.Windows.Forms.Button();
            this.lblResultado = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(44)))), ((int)(((byte)(191)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(1, 3);
            this.panel1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(539, 122);
            this.panel1.TabIndex = 0;
            this.panel1.Visible = false;
            // 
            // txtPago
            // 
            this.txtPago.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(145)))), ((int)(((byte)(0)))));
            this.txtPago.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPago.Location = new System.Drawing.Point(196, 84);
            this.txtPago.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtPago.Name = "txtPago";
            this.txtPago.Size = new System.Drawing.Size(164, 28);
            this.txtPago.TabIndex = 1;
            // 
            // lblPago
            // 
            this.lblPago.AutoSize = true;
            this.lblPago.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(145)))), ((int)(((byte)(0)))));
            this.lblPago.ForeColor = System.Drawing.Color.Black;
            this.lblPago.Location = new System.Drawing.Point(192, 45);
            this.lblPago.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblPago.Name = "lblPago";
            this.lblPago.Size = new System.Drawing.Size(135, 21);
            this.lblPago.TabIndex = 2;
            this.lblPago.Text = "Valor a ser pago";
            // 
            // lblGas
            // 
            this.lblGas.AutoSize = true;
            this.lblGas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(145)))), ((int)(((byte)(0)))));
            this.lblGas.ForeColor = System.Drawing.Color.Black;
            this.lblGas.Location = new System.Drawing.Point(192, 129);
            this.lblGas.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblGas.Name = "lblGas";
            this.lblGas.Size = new System.Drawing.Size(118, 21);
            this.lblGas.TabIndex = 4;
            this.lblGas.Text = "Valor gasolina";
            // 
            // txtGas
            // 
            this.txtGas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(145)))), ((int)(((byte)(0)))));
            this.txtGas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGas.Location = new System.Drawing.Point(196, 167);
            this.txtGas.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.txtGas.Name = "txtGas";
            this.txtGas.Size = new System.Drawing.Size(164, 28);
            this.txtGas.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(145)))), ((int)(((byte)(0)))));
            this.panel2.Controls.Add(this.lblResultado);
            this.panel2.Controls.Add(this.btnCalc);
            this.panel2.Controls.Add(this.txtPago);
            this.panel2.Controls.Add(this.lblGas);
            this.panel2.Controls.Add(this.txtGas);
            this.panel2.Controls.Add(this.lblPago);
            this.panel2.Location = new System.Drawing.Point(-4, 124);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(549, 403);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // btnCalc
            // 
            this.btnCalc.ForeColor = System.Drawing.Color.Black;
            this.btnCalc.Location = new System.Drawing.Point(196, 212);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(137, 57);
            this.btnCalc.TabIndex = 5;
            this.btnCalc.Text = "Calcular";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.ForeColor = System.Drawing.Color.Black;
            this.lblResultado.Location = new System.Drawing.Point(329, 305);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(0, 21);
            this.lblResultado.TabIndex = 6;
            // 
            // FrmExercício02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 501);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(204)))), ((int)(((byte)(213)))));
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "FrmExercício02";
            this.Text = "FrmExercício02";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtPago;
        private System.Windows.Forms.Label lblPago;
        private System.Windows.Forms.Label lblGas;
        private System.Windows.Forms.TextBox txtGas;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lblResultado;
    }
}