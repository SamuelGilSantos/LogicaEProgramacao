﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalculadora2
{
    public partial class FrmCalc : Form
    {
     

       
        public FrmCalc()
        {
            InitializeComponent();
        }

        private void FrmCalc_Load(object sender, EventArgs e)
        {
           
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {

            int num1 = int.Parse(txtN1.Text);
            float num2 = int.Parse(txtN2.Text);
            float resultado;

            resultado = num1 + num2;
            MessageBox.Show("Resultado: " + resultado);

        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtN1.Text);
            float num2 = int.Parse(txtN2.Text);
            float resultado;

            resultado = num1 - num2;
            MessageBox.Show("Resultado: " + resultado);
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtN1.Text);
            float num2 = int.Parse(txtN2.Text);
            float resultado;

            resultado = num1 / num2;
            MessageBox.Show("Resultado: " + resultado);
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtN1.Text);
            float num2 = int.Parse(txtN2.Text);
            float resultado;

            resultado = num1 * num2;
            MessageBox.Show("Resultado: " + resultado);
        }
    }
}
